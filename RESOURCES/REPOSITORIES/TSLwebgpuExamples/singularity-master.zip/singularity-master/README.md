How to install and run this template? \
It's simple, just run the following commands: 
```
npm i
npm run dev
```

https://github.com/user-attachments/assets/e7810d45-6113-4dfc-8884-5c9fbdeca65d
