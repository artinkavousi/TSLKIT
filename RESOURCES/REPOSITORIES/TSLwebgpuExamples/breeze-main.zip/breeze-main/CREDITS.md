## Credits

[Venus de Milo model](https://sketchfab.com/3d-models/venus-de-milo-903aa69c782a46619615e6df382c8045) by [chiwei](https://sketchfab.com/chiwei2333) and [Lanzi Luo](https://sketchfab.com/Thunk3D-Nancy).
 
[Qwantani Noon](https://polyhaven.com/a/qwantani_noon) HDRi background by [Greg Zaal](https://gregzaal.com/) and [Jarod Guest](https://polyhaven.com/all?a=Jarod%20Guest).

[Piazza Martin Lutero](https://polyhaven.com/a/piazza_martin_lutero) HDRi background by [Greg Zaal](https://gregzaal.com/) and [Rico Cilliers](https://www.artstation.com/rico_b3d).

[Ninomaru Teien](https://polyhaven.com/a/ninomaru_teien) HDRi background by [Greg Zaal](https://gregzaal.com/).

[Fabric texture](https://3dtextures.me/2024/06/21/fabric-lace-038/) by [3dtextures.me](https://3dtextures.me).

[Cherry petal texture](https://www.vecteezy.com/png/55531046-beautiful-cherry-blossom-petal-clipart-with-soft-elegance) by [Pram Samnak](https://www.vecteezy.com/members/pram106) on [Vecteezy](https://www.vecteezy.com/).

[Maple leaf texture](https://sketchfab.com/3d-models/low-poly-leaves-25c6b8f79b204be388ed4ea00f74f9a1) by [kaiinness](https://sketchfab.com/kaiinness).
