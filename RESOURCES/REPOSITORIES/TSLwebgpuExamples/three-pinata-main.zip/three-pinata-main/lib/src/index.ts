export { DestructibleMesh } from "./DestructibleMesh";
export { FractureOptions } from "./entities/FractureOptions";
export type { VoronoiOptions } from "./entities/FractureOptions";
export { SliceOptions } from "./entities/SliceOptions";
